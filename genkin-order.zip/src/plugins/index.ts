export default {
  install(vue: any) {
  }
}