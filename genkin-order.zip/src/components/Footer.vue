<template>
  <div class="footer">
    footer
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.footer {
  
}
</style>
