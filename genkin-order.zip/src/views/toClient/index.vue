<template>
  <NavbarClient></NavbarClient>
  <router-view />
</template>

<script lang="ts" setup>
import NavbarClient from '@/components/NavbarClient.vue'
</script>

<style>
</style>